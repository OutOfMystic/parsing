
var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "http",
            host: "193.9.126.11",
            port: parseInt(64398)
          },
          bypassList: ["localhost"]
        }
      };
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
chrome.webRequest.onAuthRequired.addListener(
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "ttNkVLRS",
                        password: "63cYXNdr"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ['blocking']
);