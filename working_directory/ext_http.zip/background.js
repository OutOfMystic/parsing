
var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "http",
            host: "46.3.133.33",
            port: parseInt(50100)
          },
          bypassList: ["localhost"]
        }
      };
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
chrome.webRequest.onAuthRequired.addListener(
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "mikheyev9",
                        password: "aXUbosImHR"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ['blocking']
);