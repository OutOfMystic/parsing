
var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "http",
            host: "45.11.126.137",
            port: parseInt(8000)
          },
          bypassList: ["localhost"]
        }
      };
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
chrome.webRequest.onAuthRequired.addListener(
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "A7YtST",
                        password: "1b9Gjw"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ['blocking']
);