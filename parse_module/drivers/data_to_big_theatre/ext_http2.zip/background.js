
var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "http",
            host: "188.130.219.47",
            port: parseInt(3000)
          },
          bypassList: ["localhost"]
        }
      };
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
chrome.webRequest.onAuthRequired.addListener(
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "JSy7VP",
                        password: "RDx0KmVaTi"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ['blocking']
);